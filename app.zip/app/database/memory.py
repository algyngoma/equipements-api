from typing import List
from app.schemas.equipement import Equipement

equipements_db: List[Equipement] = []
