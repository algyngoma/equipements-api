NOT_FOUND_MSG = "Équipement introuvable"
